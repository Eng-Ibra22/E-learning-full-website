let loginBtn = document.querySelector(".btn_1")


btn1.addEventListener("click",
    function() {
        
        
       if(btn_1==true)

        {
            alert("success")
           
        }

        else{
            alert("error")
        }
        
    }

)
