function goToPayment(title, price){
  window.location.href =
    "payment.html?title="+encodeURIComponent(title)+
    "&price="+price;
}



